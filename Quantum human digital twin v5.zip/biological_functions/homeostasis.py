from typing import Dict, List
import numpy as np

class HomeostaticSystem:
    def __init__(self):
        """Inizializza il sistema homeostatico."""
        self.needs = {
            'fame': 0.0,
            'sete': 0.0,
            'stanchezza': 0.0,
            'stress': 0.0,
            'temperatura_corporale': 37.0
        }
        
        # Parametri del sistema
        self.parameters = {
            'threshold': {
                'fame': 70.0,
                'sete': 70.0,
                'stanchezza': 80.0,
                'stress': 80.0
            },
            'increment': {
                'fame': 0.5,
                'sete': 0.3,
                'stanchezza': 0.4,
                'stress': 0.2
            },
            'decrement': {
                'fame': -1.0,
                'sete': -0.8,
                'stanchezza': -1.5,
                'stress': -0.5
            }
        }
    
    def check_needs(self) -> Dict[str, float]:
        """Verifica i livelli di bisogno."""
        # Simula l'aumento dei bisogni nel tempo
        for need in self.needs:
            if need != 'temperatura_corporale':
                self.needs[need] = min(100.0, self.needs[need] + self.parameters['increment'][need])
        
        return self.needs.copy()
    
    def update_homeostatic_state(self) -> None:
        """Aggiorna lo stato homeostatico."""
        # Simula i processi fisiologici
        self._regulate_temperature()
        self._update_stress()
        
    def update_state(self, behaviors: List[str]) -> None:
        """Aggiorna lo stato in base ai comportamenti."""
        for behavior in behaviors:
            if behavior == 'mangiare':
                self.needs['fame'] = max(0.0, self.needs['fame'] + self.parameters['decrement']['fame'])
            elif behavior == 'bere':
                self.needs['sete'] = max(0.0, self.needs['sete'] + self.parameters['decrement']['sete'])
            elif behavior == 'dormire':
                self.needs['stanchezza'] = max(0.0, self.needs['stanchezza'] + self.parameters['decrement']['stanchezza'])
                self.needs['stress'] = max(0.0, self.needs['stress'] + self.parameters['decrement']['stress'])
    
    def _regulate_temperature(self) -> None:
        """Regola la temperatura corporea."""
        # Simula la regolazione termica
        if self.needs['temperatura_corporale'] > 38.0:
            self.needs['temperatura_corporale'] -= 0.1
        elif self.needs['temperatura_corporale'] < 36.0:
            self.needs['temperatura_corporale'] += 0.1
    
    def _update_stress(self) -> None:
        """Aggiorna lo stato di stress."""
        # Simula la risposta allo stress
        if self.needs['stress'] > 80.0:
            self.needs['stress'] = min(100.0, self.needs['stress'] + 0.5)
        else:
            self.needs['stress'] = max(0.0, self.needs['stress'] - 0.1)
    
    def get_needs(self) -> Dict[str, float]:
        """Restituisce i livelli attuali dei bisogni."""
        return self.needs.copy()
