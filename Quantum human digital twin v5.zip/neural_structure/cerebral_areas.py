from typing import Dict, List, Any
import numpy as np

class CerebralAreas:
    def __init__(self):
        """Inizializza le aree cerebrali."""
        self.areas = {
            'corteccia_prefrontale': {
                'funzione': 'decisioni e ragionamento',
                'attivazione': 0.0,
                'connessioni': []
            },
            'sistema_limbico': {
                'funzione': 'emozioni e bisogni',
                'attivazione': 0.0,
                'connessioni': []
            },
            'ippocampo': {
                'funzione': 'memoria',
                'attivazione': 0.0,
                'connessioni': []
            },
            'corteccia_visiva': {
                'funzione': 'elaborazione visiva',
                'attivazione': 0.0,
                'connessioni': []
            },
            'corteccia_auditiva': {
                'funzione': 'elaborazione audio',
                'attivazione': 0.0,
                'connessioni': []
            }
        }
        
        # Inizializza le connessioni
        self.initialize_connections()
    
    def initialize_connections(self):
        """Inizializza le connessioni neurali tra le aree."""
        # Connessioni corteccia prefrontale
        self.areas['corteccia_prefrontale']['connessioni'].extend([
            'sistema_limbico',
            'ippocampo'
        ])
        
        # Connessioni sistema limbico
        self.areas['sistema_limbico']['connessioni'].extend([
            'corteccia_prefrontale',
            'ippocampo'
        ])
        
        # Connessioni ippocampo
        self.areas['ippocampo']['connessioni'].extend([
            'corteccia_prefrontale',
            'sistema_limbico'
        ])
    
    def activate_areas(self, stimolo: str) -> Dict[str, float]:
        """Attiva le aree cerebrali in risposta a uno stimolo."""
        # Elabora lo stimolo e determina l'attivazione
        activation = self._process_stimulus(stimolo)
        
        # Propaga l'attivazione
        self._propagate_activation(activation)
        
        return activation
    
    def process_information(self, informazione: Dict[str, Any]) -> Dict[str, Any]:
        """Elabora l'informazione attraverso le aree cerebrali."""
        processed_info = informazione.copy()
        
        # Elaborazione attraverso le aree
        for area, data in self.areas.items():
            processed_info = self._process_area(area, processed_info)
        
        return processed_info
    
    def _process_stimulus(self, stimolo: str) -> Dict[str, float]:
        """Elabora lo stimolo e determina l'attivazione delle aree."""
        # Simulazione della risposta cerebrale
        activation = {}
        for area in self.areas:
            activation[area] = np.random.uniform(0.0, 1.0)
        
        return activation
    
    def _propagate_activation(self, activation: Dict[str, float]) -> None:
        """Propaga l'attivazione attraverso le connessioni neurali."""
        for area, act in activation.items():
            self.areas[area]['attivazione'] = act
            
            # Propaga all'area connessa
            for connected_area in self.areas[area]['connessioni']:
                self.areas[connected_area]['attivazione'] += act * 0.5
    
    def _process_area(self, area: str, info: Dict[str, Any]) -> Dict[str, Any]:
        """Elabora l'informazione attraverso una specifica area cerebrale."""
        processed = info.copy()
        
        # Simulazione dell'elaborazione
        if area == 'corteccia_prefrontale':
            processed['decisione'] = self._make_decision(info)
        elif area == 'sistema_limbico':
            processed['emozione'] = self._generate_emotion(info)
        elif area == 'ippocampo':
            processed['memoria'] = self._store_in_memory(info)
        
        return processed
    
    def _make_decision(self, info: Dict[str, Any]) -> Dict[str, Any]:
        """Simula il processo decisionale."""
        return {
            'azione': 'decisiva',
            'probabilita': np.random.uniform(0.7, 1.0)
        }
    
    def _generate_emotion(self, info: Dict[str, Any]) -> Dict[str, float]:
        """Simula la generazione di emozioni."""
        return {
            'gioia': np.random.uniform(0.0, 1.0),
            'tristezza': np.random.uniform(0.0, 1.0),
            'ansia': np.random.uniform(0.0, 1.0)
        }
    
    def _store_in_memory(self, info: Dict[str, Any]) -> Dict[str, Any]:
        """Simula il processo di memorizzazione."""
        return {
            'tipo': 'memoria',
            'contenuto': info,
            'timestamp': datetime.now().isoformat()
        }
