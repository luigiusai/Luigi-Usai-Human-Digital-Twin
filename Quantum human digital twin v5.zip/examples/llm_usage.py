from llm_integration.llm_manager import LLMManager, LLMProvider, LLMConfig
from datetime import datetime
import json
import os
from dotenv import load_dotenv

# Carica le variabili d'ambiente
def load_environment():
    """Carica le variabili d'ambiente da .env file."""
    load_dotenv()
    
    # Se non esiste il file .env, crea uno skeleton
    if not os.path.exists('.env'):
        with open('.env', 'w') as f:
            f.write("""
# Configurazione LLM
LLM_API_KEY=your_api_key_here
LLM_PROVIDER=openai
LLM_MODEL=gpt-4
LLM_TEMPERATURE=0.7
LLM_MAX_TOKENS=2000
LLM_TIMEOUT=30
""")
        print("File .env creato. Inserisci le tue credenziali API.")
        exit(1)

def create_llm_manager():
    """Crea e configura il gestore LLM."""
    # Carica le configurazioni dall'ambiente
    config = LLMConfig(
        provider=LLMProvider(os.getenv('LLM_PROVIDER', 'openai')),
        api_key=os.getenv('LLM_API_KEY'),
        model=os.getenv('LLM_MODEL', 'gpt-4'),
        temperature=float(os.getenv('LLM_TEMPERATURE', '0.7')),
        max_tokens=int(os.getenv('LLM_MAX_TOKENS', '2000')),
        timeout=int(os.getenv('LLM_TIMEOUT', '30'))
    )
    
    return LLMManager(config)

def main():
    # Carica le variabili d'ambiente
    load_environment()
    
    # Crea il gestore LLM
    llm = create_llm_manager()
    
    print("\n=== Esempi di utilizzo del gestore LLM ===\n")
    
    # 1. Generazione di risposta semplice
    print("1. Generazione di risposta semplice:")
    prompt = "Cosa pensi dell'intelligenza artificiale?"
    response = llm.generate_response(prompt)
    print(f"Risposta: {response}\n")
    
    # 2. Estrazione di informazioni
    print("2. Estrazione di informazioni:")
    text = "Luigi è un ingegnere di 35 anni che lavora a Milano. Ha una passione per l'intelligenza artificiale e vive in una casa moderna."
    fields = ['nome', 'età', 'professione', 'città', 'interessi']
    info = llm.extract_information(text, fields)
    print(f"Informazioni estratte: {json.dumps(info, indent=2, ensure_ascii=False)}\n")
    
    # 3. Riassunto di testo
    print("3. Riassunto di testo:")
    long_text = """
    L'intelligenza artificiale è una branca dell'informatica che si occupa di creare sistemi capaci di eseguire 
    compiti che richiedono intelligenza umana. Questi compiti includono il riconoscimento del linguaggio naturale, 
    la visione artificiale, il ragionamento automatico e la pianificazione. La IA moderna si basa su tecniche 
    come il machine learning e il deep learning per migliorare le prestazioni dei sistemi.
    """
    summary = llm.summarize(long_text)
    print(f"Riassunto: {summary}\n")
    
    # 4. Traduzione
    print("4. Traduzione:")
    text_to_translate = "Ciao, come stai? Sono felice di parlare con te."
    translation = llm.translate(text_to_translate, "english")
    print(f"Traduzione: {translation}\n")
    
    # 5. Generazione di idee
    print("5. Generazione di idee:")
    topic = "nuovi progetti di intelligenza artificiale"
    ideas = llm.generate_ideas(topic, count=5)
    print("Idee generate:")
    for i, idea in enumerate(ideas, 1):
        print(f"{i}. {idea}")
    print()    
    
    # 6. Ragionamento contestuale
    print("6. Ragionamento contestuale:")
    context = {
        'nome': 'Luigi',
        'competenze': ['Python', 'AI', 'Machine Learning'],
        'esperienza': 10,
        'obiettivo': 'Sviluppare un sistema di intelligenza artificiale avanzato'
    }
    question = "Quali competenze mancano a Luigi per raggiungere il suo obiettivo?"
    reasoning = llm.reason(question, context)
    print(f"Ragionamento: {reasoning}\n")
    
    # 7. Generazione di embedding
    print("7. Generazione di embedding:")
    text = "L'intelligenza artificiale è una tecnologia rivoluzionaria"
    embedding = llm.generate_embedding(text)
    print(f"Dimensione dell'embedding: {len(embedding)}\n")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"Errore: {str(e)}")
        print("\nAssicurati di avere configurato correttamente il file .env con le tue credenziali API.")
