from digital_twin import DigitalTwin

def main():
    # Crea un'istanza del Digital Twin
    dt = DigitalTwin("MyDigitalTwin")
    
    # Apprendimento di un nuovo concetto
    concept = "Intelligenza Artificiale"
    print(f"Apprendendo il concetto: {concept}")
    dt.impara(concept)
    
    # Pensiero su un argomento
    topic = "Sviluppo futuro dell'IA"
    print(f"\nPensando su: {topic}")
    result = dt.pensa(topic)
    print(f"Risposta: {result['risposta']}")
    
    # Memorizzazione di informazioni
    info = {
        "sorgente": "articolo scientifico",
        "data": "2025-06-02",
        "relevanza": "alta"
    }
    print(f"\nMemorizzando informazioni: {info}")
    dt.memorizza(info)

if __name__ == "__main__":
    main()
