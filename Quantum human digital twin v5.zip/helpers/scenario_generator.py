from typing import Dict, Any, List, Optional
import numpy as np
from datetime import datetime
from pydantic import BaseModel

class Scenario(BaseModel):
    title: str
    description: str
    context: Dict[str, Any]
    timestamp: datetime = Field(default_factory=datetime.now)
    relevance: float = 1.0

class ScenarioGenerator:
    def __init__(self, llm_manager=None):
        """Inizializza il generatore di scenari."""
        self.llm_manager = llm_manager
        self.scenarios: List[Scenario] = []
        
    def generate_scenario(self, topic: str, context: Dict[str, Any]) -> Scenario:
        """Genera un nuovo scenario."""
        if not self.llm_manager:
            raise ValueError("LLM manager non configurato")
            
        # Prepara il prompt per la generazione
        prompt = f"""
        Genera un scenario su: {topic}
        Contesto: {json.dumps(context, ensure_ascii=False)}
        Il scenario deve includere:
        - Titolo descrittivo
        - Descrizione dettagliata
        - Contesto situato
        - Elementi rilevanti
        """
        
        response = self.llm_manager.generate_response(prompt)
        
        # Estrai le informazioni dal response
        try:
            data = json.loads(response)
            scenario = Scenario(
                title=data['title'],
                description=data['description'],
                context=data['context']
            )
        except (json.JSONDecodeError, KeyError):
            # Se il formato non è corretto, usa il response come descrizione
            scenario = Scenario(
                title=f"Scenario su {topic}",
                description=response,
                context=context
            )
            
        self.scenarios.append(scenario)
        return scenario
        
    def generate_variations(self, base_scenario: Scenario, count: int = 3) -> List[Scenario]:
        """Genera variazioni di un scenario base."""
        if not self.llm_manager:
            raise ValueError("LLM manager non configurato")
            
        prompt = f"""
        Genera {count} variazioni del seguente scenario:
        Titolo: {base_scenario.title}
        Descrizione: {base_scenario.description}
        Contesto: {json.dumps(base_scenario.context, ensure_ascii=False)}
        
        Ogni variazione deve mantenere il tema principale ma:
        - Avere un contesto leggermente diverso
        - Presentare sfumature alternative
        - Mantenere la coerenza con il tema
        """
        
        response = self.llm_manager.generate_response(prompt)
        variations = []
        
        try:
            data = json.loads(response)
            for i, var in enumerate(data['variations']):
                variations.append(Scenario(
                    title=f"Variazione {i+1} - {var['title']}",
                    description=var['description'],
                    context=var['context']
                ))
        except (json.JSONDecodeError, KeyError):
            # Se il formato non è corretto, usa il response come descrizione
            variations = [Scenario(
                title=f"Variazione {i+1} di {base_scenario.title}",
                description=response,
                context=base_scenario.context
            ) for i in range(count)]
            
        return variations
        
    def evaluate_relevance(self, scenario: Scenario, context: Dict[str, Any]) -> float:
        """Valuta la rilevanza di uno scenario."""
        if not self.llm_manager:
            return 1.0
            
        prompt = f"""
        Valuta la rilevanza di questo scenario nel contesto dato:
        Scenario: {scenario.description}
        Contesto: {json.dumps(context, ensure_ascii=False)}
        
        Restituisci un punteggio tra 0 e 1
        """
        
        response = self.llm_manager.generate_response(prompt)
        try:
            score = float(response)
            return max(0, min(1, score))
        except ValueError:
            return 1.0
            
    def get_scenarios(self, topic: Optional[str] = None) -> List[Scenario]:
        """Restituisce tutti gli scenari."""
        if topic:
            return [s for s in self.scenarios if topic.lower() in s.title.lower()]
            
        return self.scenarios.copy()
