from typing import Dict, Any, List, Optional
import numpy as np
from datetime import datetime
from pydantic import BaseModel

class KnowledgeEntry(BaseModel):
    concept: str
    relations: List[str] = []
    importance: float = 1.0
    timestamp: datetime = Field(default_factory=datetime.now)
    metadata: Dict[str, Any] = {}

class KnowledgeManager:
    def __init__(self, llm_manager=None):
        """Inizializza il gestore della conoscenza."""
        self.knowledge: Dict[str, KnowledgeEntry] = {}
        self.llm_manager = llm_manager
        
    def store(self, concept: str, data: Dict[str, Any]) -> None:
        """Memorizza un nuovo concetto."""
        if concept in self.knowledge:
            raise ValueError(f"Il concetto '{concept}' è già presente")
            
        entry = KnowledgeEntry(
            concept=concept,
            relations=data.get('relazioni', []),
            importance=data.get('importanza', 1.0),
            metadata=data.get('metadata', {})
        )
        self.knowledge[concept] = entry
        
    def retrieve(self, concept: str) -> Optional[KnowledgeEntry]:
        """Recupera un concetto."""
        return self.knowledge.get(concept)
        
    def search(self, query: str, limit: int = 5) -> List[KnowledgeEntry]:
        """Cerca concetti simili."""
        if not self.llm_manager:
            return []
            
        # Genera un embedding per la query
        query_embedding = self.llm_manager.generate_embedding(query)
        
        # Calcola la similarità con tutti i concetti
        similarities = []
        for concept, entry in self.knowledge.items():
            if not hasattr(entry, 'embedding'):
                entry.embedding = self.llm_manager.generate_embedding(concept)
            
            similarity = np.dot(entry.embedding, query_embedding)
            similarities.append((concept, similarity))
            
        # Ordina per similarità e prende i primi risultati
        similarities.sort(key=lambda x: x[1], reverse=True)
        top_concepts = [self.knowledge[c] for c, _ in similarities[:limit]]
        
        return top_concepts
        
    def generate_relations(self, concept: str) -> List[str]:
        """Genera relazioni semantiche per un concetto."""
        if not self.llm_manager:
            return []
            
        prompt = f"Genera relazioni semantiche per il concetto: {concept}"
        response = self.llm_manager.generate_response(prompt)
        return response.split('\n')
        
    def update_importance(self, concept: str, factor: float) -> None:
        """Aggiorna l'importanza di un concetto."""
        if concept not in self.knowledge:
            raise ValueError(f"Concetto '{concept}' non trovato")
            
        self.knowledge[concept].importance *= factor
        
    def get_all_concepts(self) -> List[str]:
        """Restituisce tutti i concetti memorizzati."""
        return list(self.knowledge.keys())
        
    def get_importance_score(self, concept: str) -> float:
        """Restituisce il punteggio di importanza di un concetto."""
        if concept not in self.knowledge:
            return 0.0
            
        return self.knowledge[concept].importance
