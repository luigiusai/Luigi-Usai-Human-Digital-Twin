from typing import Dict, Any, List, Optional
from pydantic import BaseModel

class BiasConfiguration(BaseModel):
    confirmation: float = 0.7
    anchoring: float = 0.5
    availability: float = 0.6
    loss_aversion: float = 0.8
    modulation: Dict[str, float] = {
        'energy': 0.5,
        'creativity': 0.4,
        'motivation': 0.3
    }

class CognitiveBiasesManager:
    def __init__(self, config: Optional[BiasConfiguration] = None):
        """Inizializza il gestore dei bias cognitivi."""
        self.config = config or BiasConfiguration()
        self.current_state = {
            'energy': 100,
            'creativity': 100,
            'motivation': 100,
            'mood': 'neutral',
            'stress': 0
        }
        
    def apply_confirmation_bias(self, new_concept: str, existing_knowledge: List[str]) -> float:
        """Applica il bias di conferma."""
        score = 0.0
        for concept in existing_knowledge:
            if new_concept.lower() in concept.lower() or concept.lower() in new_concept.lower():
                score += self.config.confirmation
        return min(1.0, score)
        
    def apply_anchoring_bias(self, reference_value: float, new_value: float) -> float:
        """Applica il bias di ancoraggio."""
        difference = abs(reference_value - new_value)
        return reference_value + (new_value - reference_value) * self.config.anchoring
        
    def apply_availability_bias(self, frequency: int) -> float:
        """Applica il bias di disponibilità."""
        return min(1.0, frequency * self.config.availability)
        
    def apply_loss_aversion(self, gain: float, loss: float) -> float:
        """Applica l'avversione alla perdita."""
        if gain > 0:
            return gain * (1 - self.config.loss_aversion)
        return loss * (1 + self.config.loss_aversion)
        
    def modulate_state(self, action: str, value: float) -> None:
        """Modula lo stato interno basato sui bias."""
        if action == 'learn':
            self.current_state['creativity'] += value * self.config.modulation['creativity']
            self.current_state['motivation'] += value * self.config.modulation['motivation']
            self.current_state['energy'] -= value * 0.1
        elif action == 'think':
            self.current_state['energy'] -= value * 0.1
            self.current_state['stress'] += value * 0.05
        
    def get_bias_score(self, concept: str, context: Dict[str, Any]) -> float:
        """Calcola il punteggio complessivo dei bias."""
        score = 1.0
        
        # Bias di conferma
        if 'existing_knowledge' in context:
            score *= self.apply_confirmation_bias(concept, context['existing_knowledge'])
        
        # Bias di disponibilità
        if 'frequency' in context:
            score *= self.apply_availability_bias(context['frequency'])
        
        return score
        
    def update_state(self, action: str, value: float) -> None:
        """Aggiorna lo stato interno."""
        self.modulate_state(action, value)
        
        # Limita i valori tra 0 e 100
        for key in ['energy', 'creativity', 'motivation']:
            self.current_state[key] = max(0, min(100, self.current_state[key]))
            
        # Limita lo stress
        self.current_state['stress'] = max(0, min(100, self.current_state['stress']))
        
    def get_current_state(self) -> Dict[str, Any]:
        """Restituisce lo stato corrente."""
        return self.current_state.copy()
