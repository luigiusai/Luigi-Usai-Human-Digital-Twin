from typing import Dict, Any, List, Optional
import numpy as np
from datetime import datetime
from pydantic import BaseModel

class MemoryEntry(BaseModel):
    content: Dict[str, Any]
    timestamp: datetime = Field(default_factory=datetime.now)
    priority: float = 1.0
    tags: List[str] = []
    metadata: Dict[str, Any] = {}

class MemorySystem:
    def __init__(self):
        """Inizializza il sistema di memoria."""
        self.working_memory: Dict[str, MemoryEntry] = {}
        self.episodic_memory: List[MemoryEntry] = []
        self.semantic_memory: Dict[str, List[MemoryEntry]] = {}
        
    def add_to_working_memory(self, content: Dict[str, Any], priority: float = 1.0) -> None:
        """Aggiunge un elemento alla memoria di lavoro."""
        if len(self.working_memory) >= 7:  # Limite di 7 elementi
            # Rimuovi l'elemento meno importante
            min_key = min(self.working_memory.items(), key=lambda x: x[1].priority)[0]
            del self.working_memory[min_key]
            
        entry = MemoryEntry(
            content=content,
            priority=priority,
            tags=["working_memory"]
        )
        self.working_memory[str(datetime.now().timestamp())] = entry
        
    def record_event(self, content: Dict[str, Any], tags: List[str] = None) -> None:
        """Registra un evento nella memoria episodica."""
        entry = MemoryEntry(
            content=content,
            tags=tags or ["episodic"]
        )
        self.episodic_memory.append(entry)
        
    def store_knowledge(self, concept: str, content: Dict[str, Any]) -> None:
        """Memorizza conoscenza nella memoria semantica."""
        entry = MemoryEntry(
            content=content,
            tags=["semantic", concept]
        )
        if concept not in self.semantic_memory:
            self.semantic_memory[concept] = []
        self.semantic_memory[concept].append(entry)
        
    def search_memory(self, query: str, memory_type: str = "all") -> List[MemoryEntry]:
        """Cerca nella memoria."""
        results = []
        
        if memory_type in ["all", "working"]:
            results.extend(self.working_memory.values())
        
        if memory_type in ["all", "episodic"]:
            results.extend(self.episodic_memory)
        
        if memory_type in ["all", "semantic"]:
            for entries in self.semantic_memory.values():
                results.extend(entries)
                
        return sorted(results, key=lambda x: x.priority, reverse=True)
        
    def get_working_memory(self) -> Dict[str, Any]:
        """Restituisce la memoria di lavoro."""
        return {k: v.content for k, v in self.working_memory.items()}
        
    def get_episodic_memory(self) -> List[Dict[str, Any]]:
        """Restituisce la memoria episodica."""
        return [e.content for e in self.episodic_memory]
        
    def get_semantic_memory(self, concept: str = None) -> Dict[str, List[Dict[str, Any]]]:
        """Restituisce la memoria semantica."""
        if concept:
            return {concept: [e.content for e in self.semantic_memory.get(concept, [])]}
            
        return {k: [e.content for e in v] for k, v in self.semantic_memory.items()}
        
    def update_memory_priority(self, entry_id: str, priority: float) -> None:
        """Aggiorna la priorità di un elemento di memoria."""
        if entry_id in self.working_memory:
            self.working_memory[entry_id].priority = priority
            return
            
        for entry in self.episodic_memory:
            if str(entry.timestamp.timestamp()) == entry_id:
                entry.priority = priority
                return
                
        for entries in self.semantic_memory.values():
            for entry in entries:
                if str(entry.timestamp.timestamp()) == entry_id:
                    entry.priority = priority
                    return
                    
    def clear_working_memory(self) -> None:
        """Pulisce la memoria di lavoro."""
        self.working_memory.clear()
