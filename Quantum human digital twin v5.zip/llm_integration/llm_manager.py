from typing import Dict, Any, List, Optional
import requests
import json
from datetime import datetime
from pydantic import BaseModel, Field
from enum import Enum

class LLMProvider(str, Enum):
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GOOGLE = "google"
    LOCAL = "local"

class LLMConfig(BaseModel):
    provider: LLMProvider
    api_key: str = Field(default="", env="LLM_API_KEY")
    model: str = Field(default="gpt-4")
    temperature: float = Field(default=0.7)
    max_tokens: int = Field(default=2000)
    timeout: int = Field(default=30)

class LLMManager:
    def __init__(self, config: LLMConfig):
        """Inizializza il gestore LLM."""
        self.config = config
        self.session = requests.Session()
        self.session.headers.update({"Content-Type": "application/json"})
        
        # Configura l'API in base al provider
        self._configure_provider()
    
    def _configure_provider(self):
        """Configura l'API in base al provider."""
        if self.config.provider == LLMProvider.OPENAI:
            self.api_url = "https://api.openai.com/v1/chat/completions"
            self.session.headers.update({
                "Authorization": f"Bearer {self.config.api_key}"
            })
        elif self.config.provider == LLMProvider.ANTHROPIC:
            self.api_url = "https://api.anthropic.com/v1/completions"
            self.session.headers.update({
                "Authorization": f"Bearer {self.config.api_key}"
            })
        elif self.config.provider == LLMProvider.GOOGLE:
            self.api_url = "https://generativelanguage.googleapis.com/v1beta/models/chat:generate"
            self.session.headers.update({
                "Authorization": f"Bearer {self.config.api_key}"
            })
        else:
            self.api_url = "http://localhost:8000/generate"
    
    def generate_response(self, prompt: str, context: Optional[Dict[str, Any]] = None) -> str:
        """Genera una risposta basata sul prompt e il contesto."""
        # Prepara il payload
        payload = self._prepare_payload(prompt, context)
        
        try:
            # Invia la richiesta
            response = self.session.post(
                self.api_url,
                json=payload,
                timeout=self.config.timeout
            )
            
            # Processa la risposta
            response.raise_for_status()
            return self._process_response(response.json())
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"Errore durante la generazione della risposta: {str(e)}")
    
    def _prepare_payload(self, prompt: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Prepara il payload per l'API in base al provider."""
        if self.config.provider == LLMProvider.OPENAI:
            return {
                "model": self.config.model,
                "messages": [{"role": "user", "content": prompt}],
                "temperature": self.config.temperature,
                "max_tokens": self.config.max_tokens
            }
        elif self.config.provider == LLMProvider.ANTHROPIC:
            return {
                "model": self.config.model,
                "prompt": prompt,
                "temperature": self.config.temperature,
                "max_tokens": self.config.max_tokens
            }
        elif self.config.provider == LLMProvider.GOOGLE:
            return {
                "model": self.config.model,
                "messages": [{"content": prompt}],
                "temperature": self.config.temperature,
                "maxOutputTokens": self.config.max_tokens
            }
        else:
            return {
                "prompt": prompt,
                "temperature": self.config.temperature,
                "max_tokens": self.config.max_tokens
            }
    
    def _process_response(self, response: Dict[str, Any]) -> str:
        """Processa la risposta dell'API in base al provider."""
        if self.config.provider == LLMProvider.OPENAI:
            return response['choices'][0]['message']['content']
        elif self.config.provider == LLMProvider.ANTHROPIC:
            return response['completion']
        elif self.config.provider == LLMProvider.GOOGLE:
            return response['candidates'][0]['content']
        else:
            return response['text']
    
    def generate_embedding(self, text: str) -> List[float]:
        """Genera un embedding per il testo."""
        try:
            response = self.session.post(
                self.api_url.replace("completions", "embeddings"),
                json={"input": text},
                timeout=self.config.timeout
            )
            
            response.raise_for_status()
            return response.json()['data'][0]['embedding']
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"Errore durante la generazione dell'embedding: {str(e)}")
    
    def summarize(self, text: str) -> str:
        """Riassuma un testo."""
        prompt = f"Riassumi questo testo in modo conciso e preciso:\n{text}"
        return self.generate_response(prompt)
    
    def translate(self, text: str, target_language: str) -> str:
        """Traduci un testo in una lingua di destinazione."""
        prompt = f"Traduci questo testo in {target_language}:\n{text}"
        return self.generate_response(prompt)
    
    def extract_information(self, text: str, fields: List[str]) -> Dict[str, Any]:
        """Estrai informazioni specifiche da un testo."""
        prompt = f"Estrai queste informazioni dal testo: {', '.join(fields)}\n\nTesto:\n{text}"
        response = self.generate_response(prompt)
        
        try:
            return json.loads(response)
        except json.JSONDecodeError:
            return {field: response for field in fields}
    
    def generate_ideas(self, topic: str, count: int = 5) -> List[str]:
        """Genera idee su un argomento."""
        prompt = f"Genera {count} idee innovative su: {topic}"
        response = self.generate_response(prompt)
        return response.split('\n')
    
    def reason(self, question: str, context: Dict[str, Any]) -> str:
        """Ragiona su una domanda in base al contesto."""
        prompt = f"Domanda: {question}\n\nContesto: {json.dumps(context, ensure_ascii=False)}\n\nRisposta:"
        return self.generate_response(prompt, context)
    
    def get_model_info(self) -> Dict[str, Any]:
        """Ottieni informazioni sul modello."""
        try:
            response = self.session.get(
                self.api_url.replace("completions", "models"),
                timeout=self.config.timeout
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            return {"error": str(e)}
