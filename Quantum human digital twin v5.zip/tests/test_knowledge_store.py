import unittest
from KnowledgeStore import KnowledgeStore
from LLMManager import LLMManager

class TestKnowledgeStore(unittest.TestCase):
    def setUp(self):
        self.llm_manager = LLMManager()
        self.knowledge_store = KnowledgeStore(self.llm_manager)
        
    def test_store_and_retrieve(self):
        """Test storing and retrieving knowledge."""
        concept = "test_concept"
        info = {
            'valore': 1.0,
            'relazioni': [],
            'bias': {
                'conferma': 0.0,
                'disponibilità': 0.0,
                'ancoraggio': 0.0,
                'loss_aversion': 0.0
            }
        }
        self.knowledge_store.store(concept, info)
        
        retrieved = self.knowledge_store.retrieve(concept)
        self.assertEqual(retrieved['valore'], info['valore'])
        self.assertEqual(retrieved['relazioni'], info['relazioni'])
        self.assertEqual(retrieved['bias'], info['bias'])
        self.assertIn('timestamp', retrieved)
        
    def test_search(self):
        """Test searching for concepts."""
        self.knowledge_store.store("test_concept_1", {"value": 1})
        self.knowledge_store.store("test_concept_2", {"value": 2})
        
        results = self.knowledge_store.search("test")
        self.assertIn("test_concept_1", results)
        self.assertIn("test_concept_2", results)
        
    def test_update_context(self):
        """Test updating context."""
        new_context = {"key": "value", "number": 42}
        self.knowledge_store.update_context(new_context)
        
        context = self.knowledge_store.get_context()
        self.assertEqual(context, new_context)
        
    def test_empty_store(self):
        """Test that store starts empty."""
        self.assertEqual(len(self.knowledge_store.knowledge), 0)

if __name__ == '__main__':
    unittest.main()
