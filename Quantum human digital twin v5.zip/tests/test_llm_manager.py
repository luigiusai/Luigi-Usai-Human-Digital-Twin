import unittest
from LLMManager import LLMManager

class TestLLMManager(unittest.TestCase):
    def setUp(self):
        self.llm_manager = LLMManager()
        
    def test_generate_response(self):
        """Test that generate_response returns a string."""
        prompt = "Test prompt"
        response = self.llm_manager.generate_response(prompt)
        self.assertIsInstance(response, str)
        self.assertIn(f"Risposta generata per: {prompt}", response)
        
    def test_update_context(self):
        """Test updating and retrieving context."""
        new_context = {"key": "value", "number": 42}
        self.llm_manager.update_context(new_context)
        retrieved = self.llm_manager.get_context()
        self.assertEqual(retrieved, new_context)
        
    def test_empty_context(self):
        """Test that context starts empty."""
        context = self.llm_manager.get_context()
        self.assertEqual(context, {})

if __name__ == '__main__':
    unittest.main()
