import unittest
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from DigitalTwin import DigitalTwin

class TestDigitalTwin(unittest.TestCase):
    def setUp(self):
        self.dt = DigitalTwin("TestDigitalTwin")
        
    def test_initialization(self):
        """Test that DigitalTwin initializes correctly."""
        self.assertEqual(self.dt.nome, "TestDigitalTwin")
        self.assertIsInstance(self.dt.stato, dict)
        self.assertIsInstance(self.dt.memoria, dict)
        self.assertIsInstance(self.dt.storia, list)
        
    def test_think(self):
        """Test basic think functionality."""
        result = self.dt.pensa("test topic")
        self.assertIsInstance(result, dict)
        
    def test_learn(self):
        """Test basic learn functionality."""
        concept = "test concept"
        self.dt.impara(concept)
        # Check that the concept is stored
        stored_knowledge = self.dt.knowledge_store.retrieve(concept)
        self.assertIsNotNone(stored_knowledge)
        # Check that the concept is in the context
        self.assertIn(concept, self.dt.contesto['conoscenze'])
        
    def test_memory(self):
        """Test memory functionality."""
        info = {"test": "data"}
        self.dt.memorizza(info)
        # Check that memory is updated
        self.assertIn("test", self.dt.memoria)
        
    def test_state(self):
        """Test state management."""
        initial_energy = self.dt.stato['energia']
        self.dt.stato['energia'] = initial_energy - 10
        self.assertEqual(self.dt.stato['energia'], initial_energy - 10)

if __name__ == '__main__':
    unittest.main()
